void *thread_funcion(void *arg) {
    int n = *((int *) arg);
    httpRequestResponsePtr request;
    fd_set read_fds, write_fds;
    struct timeval timeout;
    while (1) {
        // printf("in thread hehehe\n");
        int max_fd;
        FD_ZERO(&read_fds);
        FD_ZERO(&write_fds);
        max_fd = -1;

        for (int i = 0; i < N; i++) {
            if (fdArray[n][i] != -1) {
                FD_SET(fdArray[n][i], &read_fds);
                FD_SET(fdArray[n][i], &write_fds);
                // printf("%d was setted\n", i + 1);
                if (fdArray[n][i] > max_fd) {
                    max_fd = fdArray[n][i];
                }
            }
        }
        // printf("maxfd= %d\n", max_fd);
        timeout.tv_sec = 3;
        timeout.tv_usec =0;
        int activity = pselect(max_fd + 1, &read_fds, &write_fds, NULL, &timeout, NULL);
        // printf("actv= %d\n", activity);

        if (activity < 0) {
            logMessage(LOG_ERROR, strerror(errno), 0);
            continue;
        }
        if (activity == 0)
        {
            printf("time out. no event\n");
        }

        for (int i = 0; i < maxConnections; i++) {
            // printf("socket %d\n", httpRRArray[i].socket);
            if (httpRRArray[i].socket != -1) {
                if (FD_ISSET(httpRRArray[i].socket, &read_fds)) {
                    printf("read fds\n");
                    request = &httpRRArray[i];
                    switch(request->state)
                    {
                    case STATE_CONNECT:
                        request->readBuffer->bytesRead = 0;
                        request->readBuffer->bytesToRead = MAXPAYLOAD;
                        readRequest(request);
                        break;
                    case STATE_READ:
                        readRequest(request);
                        break;
                    }
                }
                if (httpRRArray[i].state == STATE_SEND && (httpRRArray[i].socket, &write_fds)) {
                    printf("write fds\n");

                    sendResponse(&httpRRArray[i]);
                }
                if (httpRRArray[i].state == STATE_COMPLETE || httpRRArray[i].state == STATE_ERROR) {
                    shutdown(httpRRArray[i].socket, SHUT_RDWR);
                    close(httpRRArray[i].socket);
                    for (int k = 0; k < N; k++) {
                        if (fdArray[n][k] == httpRRArray[i].socket)
                            fdArray[n][k] = -1;
                    }
                    httpRRArray[i].socket = -1;
                }
            }
        }
    }
}
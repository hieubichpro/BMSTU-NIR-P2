void sendResponse(httpRequestResponsePtr request) {
    request->state = STATE_SEND;

    int bytesSent = send(request->socket,
        request->writeBuffer->data + request->writeBuffer->bytesWritten,
        request->writeBuffer->size, 0);

    if (bytesSent == -1) {
        request->errorCode = errno;
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            return;
        }
        request->state = STATE_ERROR;
        return;
    }

    if (bytesSent > 0) {
        request->writeBuffer->bytesWritten += bytesSent;
        request->writeBuffer->size -= bytesSent;
        if (request->writeBuffer->size == 0) {
            request->state = STATE_COMPLETE;
        }
    }
}
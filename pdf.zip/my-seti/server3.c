void initializeThreads() {
    pthread_t tmpThread;
    threads = malloc(sizeof(pthread_t) * maxThreads);
    httpRRArray = malloc(sizeof(httpRequestResponse) * maxConnections);
    for (int i = 0; i < maxConnections; i++) {
        httpRRArray[i].readBuffer = malloc(sizeof(httpReadBuffer));
        httpRRArray[i].writeBuffer = malloc(sizeof(httpWriteBuffer));
        // httpRRArray[i].socket = -1; // Initialize socket to -1
    }
    for (int i = 0; i < maxThreads; i++)
    {
        for (int j = 0; j < N; j++)
        {
            fdArray[i][j] = -1;
        }
    }
    for (int i = 0; i < maxThreads; i++) {
        int *slot = malloc(sizeof(int));
        *slot = i;
        if (pthread_create(&threads[i], NULL, responseLoop, slot))
        {
            logMessage(LOG_ERROR, strerror(errno), 0);

        }
    }
}
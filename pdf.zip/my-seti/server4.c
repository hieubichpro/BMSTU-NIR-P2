    int slot = 0;
    int threadSlot = 0;
    printf("server listen on socket %d\n", listenfd);
    while (1) {
        addrlen = sizeof(clientaddr);
        httpRRArray[slot].socket = accept(listenfd, NULL, NULL);
        // httpRRArray[slot].socket = 4;

        if (httpRRArray[slot].socket < 0) {
            if (errno != EAGAIN)
                logMessage(LOG_ERROR, strerror(httpRRArray[slot].socket), 0);
        } else {
            httpRRArray[slot].state = STATE_CONNECT;
            fcntl(httpRRArray[slot].socket, F_SETFL,
                fcntl(httpRRArray[slot].socket, F_GETFL) | O_NONBLOCK);

            char abc[1024];
            sprintf(abc, "the connection %d was accepted\n", httpRRArray[slot].socket);
            logMessage(LOG_INFO, abc, 0);    

            int i = 0;
            while (fdArray[threadSlot][i] != -1) i++;
            fdArray[threadSlot][i] = httpRRArray[slot].socket;
            printf("in main slot = %d, i = %d , client = %d, aray = %d\n", slot,  i, httpRRArray[slot].socket, fdArray[threadSlot][i]);
            threadSlot = (threadSlot + 1) % maxThreads;

        }
        while (httpRRArray[slot].socket != -1) slot = (slot + 1) % maxConnections;
    }